# BrainAccess Python API

Welcome to the official Python API for BrainAccess devices.

## Quick Links

- Main Website: https://www.brainaccess.ai/
- Documentation: https://www.brainaccess.ai/software/brainaccess-sdk/
