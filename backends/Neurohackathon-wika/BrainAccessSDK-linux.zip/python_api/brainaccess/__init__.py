"""Top-level package for brainaccess."""

__author__ = """neurotechnology"""
__email__ = 'brainaccess@neurotechnology.com'
__version__ = '3.6.1'

import brainaccess.core
